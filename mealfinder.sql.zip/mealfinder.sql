-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2019 at 12:05 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mealfinder`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertising_info`
--

CREATE TABLE `advertising_info` (
  `advertising_ID` int(10) NOT NULL,
  `advertisingName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `company_ID` int(6) NOT NULL,
  `adStartDate` date NOT NULL,
  `adEndDate` date NOT NULL,
  `cost` int(10) NOT NULL,
  `paymentPlan` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_ID` int(10) NOT NULL,
  `advertiseCategory` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `advertising_info`
--

INSERT INTO `advertising_info` (`advertising_ID`, `advertisingName`, `company_ID`, `adStartDate`, `adEndDate`, `cost`, `paymentPlan`, `user_ID`, `advertiseCategory`) VALUES
(1, 'The brightest darkness', 1, '2019-04-10', '2019-06-10', 75000, 'Monthly', 23, 'popup'),
(2, 'The Loudest Silence ', 1, '2019-04-01', '2019-05-01', 37500, 'Monthly', 24, 'video'),
(3, 'The coldest fire', 2, '2019-04-01', '2019-04-03', 1500, 'Daily', 25, 'popup'),
(4, 'The Strongest of Weak ', 3, '2018-10-01', '2019-10-01', 450000, 'Anually', 26, 'video'),
(5, 'New product launch', 3, '2018-02-19', '2019-02-19', 25000, 'Monthly', 23, 'popup'),
(6, 'Website launch', 1, '2019-02-19', '2019-04-19', 5000, 'Monthly', 25, 'video'),
(7, 'Discount for new members', 5, '2019-02-19', '2020-04-19', 5000, 'Monthly', 25, 'Banner'),
(8, 'New Outlets in you area', 2, '2019-01-22', '2019-02-23', 35000, 'Monthly', 24, 'Popup'),
(9, 'Order delivery through us', 2, '2018-01-22', '2022-02-23', 75000, 'Anually', 23, 'Popup'),
(10, 'Magic hand', 3, '2019-01-22', '2019-02-23', 500, 'Daily', 24, 'Video'),
(11, 'Goodbye financial trouble', 6, '2019-01-22', '2020-02-23', 8500, 'Monthly', 25, 'Popup'),
(12, 'Earn 5000 dollars per day', 6, '2019-05-22', '2020-02-23', 15000, 'Monthly', 25, 'Video'),
(13, 'The art of deception', 2, '2018-01-01', '2019-01-30', 500000, 'Anually', 26, 'Banner');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_ID` int(10) NOT NULL,
  `blogTopic` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_ID` int(10) NOT NULL,
  `blogDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `blogTime` time NOT NULL,
  `blogDate` date NOT NULL,
  `blogViewCount` int(10) NOT NULL,
  `blogPicture` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_ID`, `blogTopic`, `user_ID`, `blogDescription`, `blogTime`, `blogDate`, `blogViewCount`, `blogPicture`) VALUES
(1, 'The best of the best cafe', 11, 'I have listed down below the best cafes I have found through meal finder...', '21:06:47', '2019-01-02', 4600, NULL),
(2, 'This is the worst restaurant', 20, 'I have eaten at many restaurants but willys dine is the worst restaurant i have eaten at..', '16:15:00', '2019-02-02', 6500, NULL),
(4, 'Travelling to Chiang Mai', 8, 'The best place to travel to during the winter..', '04:00:00', '2019-03-02', 2222, NULL),
(5, 'The best retaurant', 11, 'Willys dine is still the worst but Abeds dine on the otherhand', '16:00:00', '2019-04-02', 5000, NULL),
(6, 'Clothes', 15, 'I design clothes and they have been selling fast', '10:06:00', '2019-04-22', 556, NULL),
(11, 'Why this app is so good?', 4, 'It app is so goodddddd', '11:55:00', '2019-05-23', 10, NULL),
(12, 'First visit to Rayong', 5, 'Blah blah blah..', '08:00:00', '2019-01-14', 2200, NULL),
(14, 'Summer break', 8, 'Blah blah blah..', '22:02:00', '2019-05-14', 1200, NULL),
(15, 'Workout plan', 11, 'Blah blah blah..', '13:02:00', '2019-03-18', 4200, NULL),
(16, 'Top 10 cafes', 13, 'Blah blah blah..', '15:20:00', '2019-01-23', 3200, NULL),
(17, 'Best resstaurant for students', 19, 'Blah blah blah..', '09:20:00', '2019-02-27', 7500, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE `company_info` (
  `company_ID` int(6) NOT NULL,
  `companyName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `companyAddress` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `companyPhone` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` (`company_ID`, `companyName`, `companyAddress`, `companyPhone`) VALUES
(1, 'Willy Love You', '123-456, Sathorn, Bangruk, Bangkok, Thailand ', '0934567894'),
(2, 'Abed Kaut Yub', '456, Bangna, Thailand', '0934567890'),
(3, 'Sabb Love RC', '456-789, RC, NEWYORK, USA', '0934567897'),
(4, 'Panther Inc.', '241-Wankanda, Wakanda', '0154798521'),
(5, 'Avengers Org.', '220-dead road, Earth', '0954648521'),
(6, 'Iwill RobU Inc.', '22/35-random road, Panama', '0854633521');

-- --------------------------------------------------------

--
-- Table structure for table `date_list`
--

CREATE TABLE `date_list` (
  `open_ID` int(3) NOT NULL,
  `monday` tinyint(1) NOT NULL,
  `tuesday` tinyint(1) NOT NULL,
  `wednesday` tinyint(1) NOT NULL,
  `thursday` tinyint(1) NOT NULL,
  `friday` tinyint(1) NOT NULL,
  `saturday` tinyint(1) NOT NULL,
  `sunday` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `date_list`
--

INSERT INTO `date_list` (`open_ID`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1),
(2, 1, 1, 1, 1, 1, 0, 0),
(3, 1, 1, 1, 1, 1, 1, 0),
(4, 0, 0, 0, 0, 0, 1, 1),
(5, 0, 0, 0, 0, 0, 0, 1),
(6, 1, 1, 1, 1, 0, 0, 1),
(7, 0, 1, 1, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `meal_list`
--

CREATE TABLE `meal_list` (
  `meal_ID` int(10) NOT NULL,
  `mealName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mealType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(4) NOT NULL,
  `ingredient` varchar(10000) COLLATE utf8_unicode_ci NOT NULL,
  `spicyLevel` int(1) NOT NULL,
  `nationality` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `meal_list`
--

INSERT INTO `meal_list` (`meal_ID`, `mealName`, `mealType`, `price`, `ingredient`, `spicyLevel`, `nationality`, `restaurant_ID`) VALUES
(1, 'Grilled Meat', 'Buffet', 259, 'Beef, Pork, Sea Food ', 0, '-', 1),
(2, 'Shabu', 'Buffet', 239, 'Meat, Pork, Vegetable, egg ', 0, '-', 2),
(3, 'Shabu', 'Buffet', 289, 'Meat, Pork, Tempura, Vegetable, Ice-cream', 0, '-', 3),
(4, 'Shabu', 'Buffet', 259, 'Meat, Pork, Shrimp, Vegetable ', 0, '-', 4),
(5, 'Mama Gohang', 'One-dish', 70, 'Instant-noddle, Pork, Garlic, Vegetable, Chilli-Paste', 1, 'Thai', 5),
(6, 'Tomyum Kai Num+Rice', 'One-dish', 55, 'Fried egg, Pork, Tomyum, Rice', 3, 'Thai', 5),
(7, 'Bacon run kai', 'One-dish', 55, 'Bacon, Egg, Rice', 0, '-', 5),
(8, 'Grilled Meat', 'Buffet', 259, 'Beef, Pork, Vegetable', 0, '-', 6),
(9, 'Salmon Sashimi', 'One-dish', 170, 'Raw Salmon', 0, 'Japan', 7),
(10, 'Rice+Beef', 'One-dish', 155, 'Rice, Beef', 0, 'Japan', 7),
(11, 'Beef Steak', 'One-dish', 220, 'Beef, Potato, Salad', 0, '-', 8),
(12, 'Pork Chop', 'One-dish', 180, 'Pork, Potato, Salad', 0, '-', 8),
(13, 'Pasta', 'One-dish', 175, 'Pasta, Ham', 0, 'Italy', 8),
(14, 'Grilled Meat', 'Buffet', 259, 'Meat, Pork, Vegetable ', 0, '-', 9),
(15, 'Shabu', 'Buffet', 269, 'Meat, Pork, Vegetable', 0, '-', 10),
(16, 'Shabu', 'Buffet', 269, 'Meat, Pork, Vegetable', 0, '-', 11),
(17, 'Som Tum', 'One-dish', 69, 'Papaya, Shrimp ', 7, 'Thai', 12),
(18, 'Grilled Fish', 'One-dish', 180, 'Fish', 0, '-', 12),
(19, 'Kaprow Kai + Fried egg', 'One-dish', 55, 'Chicken, Rice, Egg, Kaprow', 4, 'Thai', 13),
(20, 'Rice + chicken fill with egg', 'One-dish', 65, 'Rice, Chicken, Egg', 0, 'Japan', 14),
(21, 'Bacon + Egg', 'One-dish', 120, 'Bacon, Egg', 0, 'Western ', 15),
(22, 'ete Ice cream ', 'Dessert', 80, 'Ice cream', 0, '-', 15),
(23, 'Thai Tea', 'Dessert', 65, 'Tea', 0, 'Thai', 16),
(24, 'Hot Chocolate ', 'Dessert', 45, 'Chocolate', 0, 'Western', 16),
(25, 'Ice lemon tea', 'Dessert', 55, 'Lemon tea', 0, '-', 17),
(26, 'Ice Green Tea', 'Dessert', 45, 'Green tea', 0, '-', 18),
(27, 'Joke', 'One-dish', 45, 'Pork, Egg, Rice', 0, '-', 19),
(28, 'Hainanese chicken rice', 'One-dish', 65, 'Rice, Chicken', 0, '-', 19),
(29, 'Cookie', 'Dessert', 40, 'Butter, Flour', 0, 'Western', 20),
(30, 'Cake', 'Dessert', 120, 'Flour, Cream', 0, 'Western', 20);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_ID` int(10) NOT NULL,
  `newsDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `newsDate` date NOT NULL,
  `user_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_ID`, `newsDescription`, `newsDate`, `user_ID`) VALUES
(1, 'New themes added for a more unique user experience', '2019-02-01', 26),
(2, '50 new restaurants have joined us!', '2019-03-01', 23),
(3, 'We are working on a new app for our website, stayed tuned for more updates!', '2019-04-01', 25),
(4, 'Website interface updated for a more enchanced user experience', '2019-05-01', 25),
(5, 'Get ready for great summer discounts for your favourite restaurants! Coming soon!', '2019-05-28', 25);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_ID` int(3) NOT NULL,
  `PaymentWay` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_ID`, `PaymentWay`) VALUES
(1, 'Cash'),
(2, 'Credit Card'),
(3, 'Debit Card'),
(4, 'Prompt Pay'),
(5, 'QR payment');

-- --------------------------------------------------------

--
-- Table structure for table `payment_register`
--

CREATE TABLE `payment_register` (
  `payment_register_ID` int(10) NOT NULL,
  `payment_ID` int(3) NOT NULL,
  `restaurant_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_register`
--

INSERT INTO `payment_register` (`payment_register_ID`, `payment_ID`, `restaurant_ID`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 7),
(9, 1, 8),
(10, 1, 9),
(11, 1, 10),
(12, 1, 11),
(13, 1, 12),
(14, 1, 13),
(15, 1, 14),
(16, 1, 15),
(17, 2, 15),
(18, 3, 15),
(19, 4, 15),
(20, 5, 15),
(21, 3, 14),
(22, 3, 11),
(23, 3, 9),
(24, 3, 6),
(25, 3, 1),
(26, 3, 3),
(27, 3, 5),
(28, 2, 2),
(29, 2, 8),
(30, 2, 13),
(31, 2, 10),
(32, 2, 7),
(33, 4, 14),
(34, 4, 12),
(35, 4, 11),
(36, 4, 10),
(37, 4, 1),
(38, 4, 2),
(39, 4, 4),
(40, 4, 5),
(41, 4, 8),
(42, 5, 8),
(43, 5, 13),
(44, 5, 12),
(45, 5, 10),
(46, 5, 8),
(47, 5, 6),
(48, 5, 4),
(49, 5, 2),
(50, 5, 16),
(51, 5, 18),
(52, 1, 16),
(53, 1, 17),
(54, 1, 18),
(55, 3, 18),
(56, 2, 17),
(57, 5, 16),
(58, 4, 18),
(59, 4, 17),
(60, 1, 19),
(61, 2, 19),
(62, 2, 19),
(63, 3, 19),
(64, 4, 19),
(65, 5, 19),
(66, 5, 20),
(67, 1, 20),
(68, 3, 20),
(69, 4, 20);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_ID` int(10) NOT NULL,
  `user_ID` int(10) NOT NULL,
  `reportTitle` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `reportDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `reportPicture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reportTime` time NOT NULL,
  `reportDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_ID`, `user_ID`, `reportTitle`, `reportDescription`, `reportPicture`, `reportTime`, `reportDate`) VALUES
(1, 6, 'Misinformation', 'The resturant timing information was wrong', NULL, '12:15:00', '2019-04-09'),
(2, 8, 'website crashed', 'The website crashed last night night.', NULL, '06:00:00', '2019-05-22'),
(3, 11, 'Server timeout', 'Server times out everytime us hit search', NULL, '09:00:00', '2018-01-01'),
(4, 13, 'Not working', '0 results return when i try to find restaurant', NULL, '12:00:00', '2019-05-03'),
(11, 8, 'Forget password', 'asdasdasd', NULL, '04:23:00', '2019-05-05'),
(12, 5, 'Forgot password', 'The problem..', '', '17:00:00', '2019-03-15'),
(13, 9, 'screen froze', 'The problem..', '', '09:00:00', '2019-05-05'),
(14, 12, 'search page unavailable', 'The problem..', '', '12:00:00', '2019-04-09'),
(15, 12, 'cannot view history', 'The problem bla bla..', '', '16:00:00', '2019-05-09'),
(16, 17, 'cannot sign in', 'The problem bla bla..', '', '22:00:00', '2019-05-13'),
(17, 20, 'broken link', 'The problem bla bla..', '', '23:00:00', '2019-04-13'),
(18, 14, 'missing resutaurent', 'The problem bla bla..', '', '04:35:00', '2019-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_comment`
--

CREATE TABLE `restaurant_comment` (
  `comment_ID` int(10) NOT NULL,
  `history_ID` int(10) NOT NULL,
  `restaurant_Rate` int(1) NOT NULL,
  `restaurantComment` text COLLATE utf8_unicode_ci NOT NULL,
  `commentDate` date NOT NULL,
  `commentTime` time NOT NULL,
  `meal_Rate` int(1) NOT NULL,
  `meal_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `restaurant_comment`
--

INSERT INTO `restaurant_comment` (`comment_ID`, `history_ID`, `restaurant_Rate`, `restaurantComment`, `commentDate`, `commentTime`, `meal_Rate`, `meal_ID`) VALUES
(1, 1, 4, 'Good environment, food is good but takes long time to be served', '2019-05-11', '17:00:00', 5, 1),
(2, 14, 5, 'Good environment, best food iin town served fast', '2019-05-05', '09:00:00', 5, 6),
(3, 33, 2, 'Cake went bad', '2019-04-21', '22:00:00', 1, 30),
(4, 24, 3, 'Mediocre tasting food', '2019-03-24', '22:00:00', 3, 21);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_info`
--

CREATE TABLE `restaurant_info` (
  `restaurant_ID` int(10) NOT NULL,
  `restaurantName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `restaurantAddress` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `restaurantPhone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `openTimeWeekday` time DEFAULT NULL,
  `openTimeWeekend` time DEFAULT NULL,
  `closeTime` time DEFAULT NULL,
  `storeType` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `restaurantDes` text COLLATE utf8_unicode_ci NOT NULL,
  `viewCount` int(10) NOT NULL,
  `open_ID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `restaurant_info`
--

INSERT INTO `restaurant_info` (`restaurant_ID`, `restaurantName`, `restaurantAddress`, `restaurantPhone`, `openTimeWeekday`, `openTimeWeekend`, `closeTime`, `storeType`, `restaurantDes`, `viewCount`, `open_ID`) VALUES
(1, 'Ant-Ni-Mal', '123-456, Phuttha Bucha Road, Thungkru, Bangkok\r\n', '0817215347', '17:00:00', '16:00:00', '22:00:00', 'Restaurant ', 'Meat, Pork many food buffet', 0, 1),
(2, 'Guma Shabu', '124-567, Phuttha Bucha Road, Thungkru, Bangkok', '0879247812', '14:00:00', '16:00:00', '22:00:00', 'Restaurant ', 'Meat and pork buffet', 0, 1),
(3, 'Oooi Ramen', '108-546, Phuttha Bucha Road, Thungkru, Bangkok', '024587945', '17:05:00', '18:00:00', '23:00:00', 'Restaurant ', 'Meat and pork buffet', 0, 3),
(4, 'Indy Shabu', '102-987, Phuttha Bucha Road, Thungkru, Bangkok', '034613888', '17:00:00', '17:30:00', '23:00:00', 'Restaurant ', 'Meat and pork buffet', 0, 2),
(5, 'Pa Si Kon', '102-854, Pracha Uthit, Thungkru, Bangkok', '024798562', '07:00:00', '09:00:00', '22:00:00', 'Restaurant ', 'Street restaurant, with 4 nice grandma', 15, 3),
(6, 'Panda Grill', '100-007, Phuttha Bucha Road, Thungkru, Bangkok', '0896478124', '15:00:00', '16:00:00', '23:00:00', 'Restaurant ', 'Meat and pork buffet', 0, 1),
(7, 'Bun Town', '177-624, Phuttha Bucha Road, Thungkru, Bangkok', '027148965', '17:00:00', '16:00:00', '23:00:00', 'Restaurant ', 'Sushi with other menu as well', 1, 2),
(8, 'Bisto', '100-45, Pracha Uthit45, Thungkru, Bangkok', '0987542456', '17:00:00', '16:00:00', '21:00:00', 'Restaurant ', 'Steak and Spaghetti', 0, 2),
(9, 'Kam To', '106-75, Pracha Uthit, Thungkru, Bangkok', '0347891245', '15:00:00', '16:00:00', '23:00:00', 'Restaurant ', 'Meat buffet ', 1, 3),
(10, 'Kin Kin', '100-38, Pracha Uthit, Thungkru, Bangkok', '0864792546', '14:00:00', '16:00:00', '22:00:00', 'Restaurant ', 'Meat and pork buffet', 1, 2),
(11, 'Au Kao Au Nam', '	\r\n111-222, Phuttha Bucha Road, Thungkru, Bangkok', '0956784567', '14:00:00', '17:30:00', '22:00:00', 'Restaurant ', 'Pork and meat buffet', 5, 3),
(12, 'Som Tum Korat', '202-454, Pracha Uthit, Thungkru, Bangkok', '0359468795', '14:00:00', '15:00:00', '22:00:00', 'Restaurant ', 'Som Tum', 5, 3),
(13, 'Jae Jim', '100-45, Pracha Uthit, Thungkru, Bangkok', '0348647812', '08:00:00', '08:30:00', '22:00:00', 'Restaurant ', 'Street food ', 2, 3),
(14, 'Jae Pon', '100-451, Pracha Uthit, Thungkru, Bangkok', '0924781678', '09:00:00', '09:00:00', '21:00:00', 'Restaurant ', 'Street with 2nd floor in the store ', 10, 3),
(15, 'Rung Mod', '120-451, Pracha Uthit, Thungkru, Bangkok', '0896587498', '09:00:00', '09:00:00', '21:00:00', 'Cafe', '2nd floor of cafe that you can sit all day, they also have meal and dessert for you', 0, 1),
(16, 'Chin Cha', '140-450, Pracha Uthit, Thungkru, Bangkok', '024561487', '09:00:00', '10:00:00', '22:00:00', 'Cafe', 'Hot coffee with clam environment', 4, 4),
(17, 'D\'oro', '126 Pracha Uthit Rd., Bang Mod, Thung Khru, Bangkok 10140, Thailand', '021459852', '08:00:00', '10:00:00', '19:00:00', 'Cafe', 'The cafe in the university that we can enjoy with not far distance', 1, 3),
(18, 'Amazon', '126 Pracha Uthit Rd., Bang Mod, Thung Khru, Bangkok', '024786541', '07:00:00', '09:00:00', '21:00:00', 'Cafe', 'Cafe in the university near the library', 2, 2),
(19, 'Joke Moo Thong', '122, Pracha Uthit, Thungkru, Bangkok', '0874126587', NULL, NULL, NULL, 'Restaurant ', 'Restaurant that open 24 hour', 2, 1),
(20, 'Ponmaree', '122-168, Pracha Uthit, Thungkru, Bangkok', '0378561478', '11:00:00', '11:00:00', '21:00:00', 'Bakery ', 'Nice and sweet snack and bread ', 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_pictures`
--

CREATE TABLE `restaurant_pictures` (
  `restaurant_Pic_ID` int(10) NOT NULL,
  `restaurant_Picture` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_ID` int(10) NOT NULL,
  `main_Pic` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `theme_info`
--

CREATE TABLE `theme_info` (
  `theme_id` int(11) NOT NULL,
  `themeName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `themeDescription` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `themeStartDate` date NOT NULL,
  `themeEndDate` date NOT NULL,
  `themeViewCount` int(11) NOT NULL,
  `themePicture` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `theme_info`
--

INSERT INTO `theme_info` (`theme_id`, `themeName`, `themeDescription`, `themeStartDate`, `themeEndDate`, `themeViewCount`, `themePicture`) VALUES
(1, 'Couple Theme', 'Appealing towards couples. Expirence intimate setting with your partner.', '2018-05-30', '2019-05-30', 19, NULL),
(2, 'Family Theme', 'A fun setting to enjoy family time with.', '2019-05-30', '2022-05-30', 6, NULL),
(3, 'Friends Theme', 'A fun setting for groups to enjoy and be loud.', '2019-05-30', '2020-05-30', 16, NULL),
(4, 'Halloween Theme', 'A spooky setting to expirience a halloween vibe.', '2019-10-01', '2019-10-31', 2, NULL),
(5, 'New year Theme', 'Festive environment with lots of colors.', '2019-04-01', '2019-04-30', 3, NULL),
(6, 'The late late night', 'The night is dark and full of terror, let us help be you safest place.', '2019-03-12', '2019-05-02', 33, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `theme_register`
--

CREATE TABLE `theme_register` (
  `theme_Register_ID` int(10) NOT NULL,
  `restaurant_ID` int(10) NOT NULL,
  `theme_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `theme_register`
--

INSERT INTO `theme_register` (`theme_Register_ID`, `restaurant_ID`, `theme_ID`) VALUES
(1, 8, 1),
(2, 1, 3),
(3, 2, 2),
(4, 3, 2),
(5, 4, 2),
(6, 5, 3),
(7, 6, 2),
(8, 7, 1),
(9, 8, 1),
(10, 9, 3),
(11, 10, 2),
(12, 11, 3),
(13, 12, 2),
(14, 12, 3),
(15, 12, 1),
(16, 13, 3),
(17, 14, 1),
(18, 15, 1),
(19, 18, 1),
(20, 15, 5),
(21, 15, 3),
(22, 16, 4),
(23, 17, 4),
(24, 18, 5),
(25, 19, 5),
(26, 20, 4);

-- --------------------------------------------------------

--
-- Table structure for table `user_history`
--

CREATE TABLE `user_history` (
  `history_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `restaurant_ID` int(11) NOT NULL,
  `historyDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_history`
--

INSERT INTO `user_history` (`history_ID`, `user_ID`, `restaurant_ID`, `historyDate`) VALUES
(1, 1, 1, '2019-01-03'),
(2, 4, 1, '2019-01-04'),
(3, 15, 1, '2019-01-15'),
(4, 8, 2, '2019-02-15'),
(5, 10, 3, '2019-02-14'),
(6, 11, 4, '2019-04-15'),
(7, 12, 4, '2019-01-16'),
(8, 15, 4, '2019-03-14'),
(9, 17, 4, '2019-02-14'),
(10, 1, 5, '2019-05-10'),
(11, 2, 5, '2019-05-10'),
(12, 3, 5, '2019-05-10'),
(13, 4, 5, '2019-05-10'),
(14, 21, 5, '2019-05-21'),
(15, 22, 5, '2019-05-14'),
(16, 15, 5, '2019-05-20'),
(17, 13, 6, '2019-05-17'),
(18, 12, 7, '2019-05-14'),
(19, 21, 8, '2019-05-15'),
(20, 14, 9, '2019-04-17'),
(21, 19, 10, '2019-05-23'),
(22, 9, 9, '2019-05-15'),
(23, 3, 9, '2019-05-07'),
(24, 20, 15, '2019-03-15'),
(25, 15, 18, '2019-05-28'),
(26, 11, 12, '2019-02-12'),
(27, 1, 13, '2019-05-14'),
(28, 20, 14, '2019-04-30'),
(29, 16, 16, '2019-05-23'),
(30, 10, 17, '2019-05-17'),
(31, 18, 19, '2019-02-13'),
(32, 5, 20, '2019-03-21'),
(33, 17, 20, '2019-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fullName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `userPhone` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `email`, `fullName`, `userPhone`, `password`, `rank`, `profile_picture`, `birthDate`) VALUES
(1, 'essa@joke.com', 'Essa Willy', '0235468794', 'essat', 'client', NULL, '1969-01-01'),
(2, 'abetisus@joke.com', 'Abed Isus', '1911911111', 'eieiza556', 'client', NULL, '2016-10-03'),
(3, 'miki@rattrap.com', 'Mikki Mouse', '0000000001', 'jerry', 'client', NULL, '1990-02-11'),
(4, 'pleum@usa.com', 'Pleum Plum', '0000000002', 'Palm', 'client', NULL, '1998-05-22'),
(5, 'saab@suburb.com', 'Saab Daab', '0000000003', 'baad', 'client', NULL, '1999-05-22'),
(6, 'me@you.com', 'Iam Me', '0000000004', 'them', 'client', NULL, '1997-05-22'),
(8, 'random@user.com', 'Random Name', '0000000005', 'asdf', 'client', NULL, '1998-07-20'),
(9, 'jimi@heaven.com', 'Jimi Hendrix', '0000000006', 'wing', 'client', NULL, '1990-02-05'),
(10, 'mayer@currentmood.com', 'John Mayer', '0000000015', 'gravity', 'client', NULL, '1970-12-12'),
(11, 'khaled@another1.com', 'Dj Khaled', '0000000007', 'ennathoaan', 'client', NULL, '2000-04-28'),
(12, 'eminem@realslimshady.com', 'Marshall Mathers', '0000000008', 'mnm', 'client', NULL, '1960-02-11'),
(13, 'dre@who.com', 'Dr Dre', '0000000009', 'forgotabout', 'client', NULL, '1980-08-13'),
(14, 'tom@geography.com', 'Tom Misch', '0000000010', 'discoYes', 'client', NULL, '1985-04-26'),
(15, 'paak@yeslawd.com', 'Anserson Paak', '0000000011', 'makeitbetter', 'client', NULL, '1988-03-21'),
(16, 'she@pridenjoy.com', 'Stevie Rayvaughan', '0000000012', 'littlelamb', 'client', NULL, '1950-01-22'),
(17, 'eric@slowhand.com', 'Eric Clapton', '0000000013', 'layla', 'client', NULL, '1960-08-19'),
(18, 'arian@7rings.com', 'Ariana Grande', '0000000014', 'yeet', 'client', NULL, '1990-07-17'),
(19, 'jannet@random.com', 'Jannet Jackson', '0000000016', 'jackson', 'client', NULL, '1977-03-03'),
(20, 'emma@stoner.com', 'Emma Stone', '0000000018', 'pale', 'client', NULL, '1988-07-09'),
(21, 'yuvett@notfunny.com', 'yuvett young', '0000000019', 'punkrock', 'client', NULL, '1989-11-15'),
(22, 'peter@familyguy.com', 'Peter Griffin', '0000000020', 'louis', 'client', NULL, '1982-12-13'),
(23, 'pleum164@mealfinder.com', 'Wattana Yubonbandidkul', '0964567895', '123456789', 'admin', NULL, '1999-12-07'),
(24, 'pleum163@mealfinder.com', 'Yubona Watdee', '0964567874', '456789', 'admin', NULL, '1999-05-14'),
(25, 'pleum162@mealfinder.com', 'Wasdwa Deejuk', '0964567777', '789456', 'admin', NULL, '1999-05-06'),
(26, 'pleum161@mealfinder.com', 'Dfdas Kalus', '0964567548', '456852', 'admin', NULL, '1999-12-11'),
(27, 'sabb@mail.com', 'Sabb Hello', '0984578945', '123456789', 'restaurantOwner', NULL, '2019-05-22'),
(31, 'plum5000@gmail.com', 'Sabb Smile', '0987451879', '123456', 'client', NULL, '2019-05-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertising_info`
--
ALTER TABLE `advertising_info`
  ADD PRIMARY KEY (`advertising_ID`),
  ADD KEY `company_ID` (`company_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `company_info`
--
ALTER TABLE `company_info`
  ADD PRIMARY KEY (`company_ID`);

--
-- Indexes for table `date_list`
--
ALTER TABLE `date_list`
  ADD PRIMARY KEY (`open_ID`);

--
-- Indexes for table `meal_list`
--
ALTER TABLE `meal_list`
  ADD PRIMARY KEY (`meal_ID`),
  ADD KEY `restaurant_ID` (`restaurant_ID`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_ID`);

--
-- Indexes for table `payment_register`
--
ALTER TABLE `payment_register`
  ADD PRIMARY KEY (`payment_register_ID`),
  ADD KEY `restaurant_ID` (`restaurant_ID`),
  ADD KEY `payment_ID` (`payment_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `restaurant_comment`
--
ALTER TABLE `restaurant_comment`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `meal_ID` (`meal_ID`),
  ADD KEY `history_ID` (`history_ID`);

--
-- Indexes for table `restaurant_info`
--
ALTER TABLE `restaurant_info`
  ADD PRIMARY KEY (`restaurant_ID`),
  ADD KEY `open_ID` (`open_ID`);

--
-- Indexes for table `restaurant_pictures`
--
ALTER TABLE `restaurant_pictures`
  ADD PRIMARY KEY (`restaurant_Pic_ID`),
  ADD KEY `restaurant_ID` (`restaurant_ID`);

--
-- Indexes for table `theme_info`
--
ALTER TABLE `theme_info`
  ADD PRIMARY KEY (`theme_id`);

--
-- Indexes for table `theme_register`
--
ALTER TABLE `theme_register`
  ADD PRIMARY KEY (`theme_Register_ID`),
  ADD KEY `theme_ID` (`theme_ID`),
  ADD KEY `restaurant_ID` (`restaurant_ID`);

--
-- Indexes for table `user_history`
--
ALTER TABLE `user_history`
  ADD PRIMARY KEY (`history_ID`),
  ADD KEY `user_ID` (`user_ID`),
  ADD KEY `restaurant_ID` (`restaurant_ID`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertising_info`
--
ALTER TABLE `advertising_info`
  MODIFY `advertising_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `company_info`
--
ALTER TABLE `company_info`
  MODIFY `company_ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `date_list`
--
ALTER TABLE `date_list`
  MODIFY `open_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `meal_list`
--
ALTER TABLE `meal_list`
  MODIFY `meal_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment_register`
--
ALTER TABLE `payment_register`
  MODIFY `payment_register_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `restaurant_comment`
--
ALTER TABLE `restaurant_comment`
  MODIFY `comment_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `restaurant_info`
--
ALTER TABLE `restaurant_info`
  MODIFY `restaurant_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `restaurant_pictures`
--
ALTER TABLE `restaurant_pictures`
  MODIFY `restaurant_Pic_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `theme_info`
--
ALTER TABLE `theme_info`
  MODIFY `theme_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `theme_register`
--
ALTER TABLE `theme_register`
  MODIFY `theme_Register_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `user_history`
--
ALTER TABLE `user_history`
  MODIFY `history_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `advertising_info`
--
ALTER TABLE `advertising_info`
  ADD CONSTRAINT `advertising_info_ibfk_1` FOREIGN KEY (`company_ID`) REFERENCES `company_info` (`company_ID`),
  ADD CONSTRAINT `advertising_info_ibfk_2` FOREIGN KEY (`user_ID`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `blog`
--
ALTER TABLE `blog`
  ADD CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `meal_list`
--
ALTER TABLE `meal_list`
  ADD CONSTRAINT `meal_list_ibfk_1` FOREIGN KEY (`restaurant_ID`) REFERENCES `restaurant_info` (`restaurant_ID`);

--
-- Constraints for table `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `payment_register`
--
ALTER TABLE `payment_register`
  ADD CONSTRAINT `payment_register_ibfk_1` FOREIGN KEY (`restaurant_ID`) REFERENCES `restaurant_info` (`restaurant_ID`),
  ADD CONSTRAINT `payment_register_ibfk_2` FOREIGN KEY (`payment_ID`) REFERENCES `payment` (`Payment_ID`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `restaurant_comment`
--
ALTER TABLE `restaurant_comment`
  ADD CONSTRAINT `restaurant_comment_ibfk_1` FOREIGN KEY (`meal_ID`) REFERENCES `meal_list` (`meal_ID`),
  ADD CONSTRAINT `restaurant_comment_ibfk_2` FOREIGN KEY (`history_ID`) REFERENCES `user_history` (`history_ID`);

--
-- Constraints for table `restaurant_info`
--
ALTER TABLE `restaurant_info`
  ADD CONSTRAINT `restaurant_info_ibfk_1` FOREIGN KEY (`open_ID`) REFERENCES `date_list` (`open_ID`);

--
-- Constraints for table `restaurant_pictures`
--
ALTER TABLE `restaurant_pictures`
  ADD CONSTRAINT `restaurant_pictures_ibfk_1` FOREIGN KEY (`restaurant_ID`) REFERENCES `restaurant_info` (`restaurant_ID`);

--
-- Constraints for table `theme_register`
--
ALTER TABLE `theme_register`
  ADD CONSTRAINT `theme_register_ibfk_1` FOREIGN KEY (`theme_ID`) REFERENCES `theme_info` (`theme_id`),
  ADD CONSTRAINT `theme_register_ibfk_2` FOREIGN KEY (`restaurant_ID`) REFERENCES `restaurant_info` (`restaurant_ID`);

--
-- Constraints for table `user_history`
--
ALTER TABLE `user_history`
  ADD CONSTRAINT `user_history_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `user_info` (`user_id`),
  ADD CONSTRAINT `user_history_ibfk_2` FOREIGN KEY (`restaurant_ID`) REFERENCES `restaurant_info` (`restaurant_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
